#include "ne.h"
#include "router.h"
//#include "endian.c"

int main(int argc, char **argv)
{
  //check for incorrect number of arguments
   if (argc != 5) 
     {
       exit(1);
     }
  int listenfd_udp, port_udp;
  port_udp = atoi(argv[4]); //the client udp port
  listenfd_udp = open_listenfd_udp(port_udp);
  
  int router_id;
  router_id = atoi(argv[1]);
  
  struct sockaddr_in serveraddr;
  socklen_t servlen = sizeof(serveraddr);
  bzero((char *) &serveraddr, sizeof(serveraddr)); 
  inet_aton(argv[2],&serveraddr.sin_addr); //to specify the address from the command line
  serveraddr.sin_family = AF_INET;  
  serveraddr.sin_port = htons((unsigned short)atoi(argv[3]));  

  struct pkt_INIT_REQUEST req;  
  req.router_id = htonl(router_id); //since we are sending it over the network, so convert from host to network order
  if ((sendto(listenfd_udp, &req, sizeof(struct pkt_INIT_REQUEST), 0, (struct sockaddr *)&serveraddr, (socklen_t)servlen)) < 0) 
    {
      perror("Failed to send.!!");
      return -1;
    }

  //printf("1\n");
  //now send it back to the client
  struct pkt_INIT_RESPONSE resp;
  if (recvfrom(listenfd_udp, &resp, sizeof(struct pkt_INIT_RESPONSE), 0, (struct sockaddr *)&serveraddr, &servlen) == -1) 
    {
      perror("Failed to receive.!!");
      return -1;
    }
  //printf("2\n");
  //printf("%c\n", &resp);

  //now convert the response packet to host order from network order and initialize the routing tables for the node
  ntoh_pkt_INIT_RESPONSE (&resp);
  return 0;
}


int open_listenfd_udp(int port_udp)
{
  int listenfd, optval = 1; 
  struct sockaddr_in serveraddr; 
  
  /* Create a socket descriptor */ 
  if ((listenfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    perror("Cannot create UDP socket.!");
    return -1;
  }
  /* Eliminates "Address already in use" error from bind. */ 
  if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR,(const void *)&optval , sizeof(int)) < 0) { 
    return -1; 
  }
  /* Listenfd will be an endpoint for all requests to port on any IP address for this host */ 
  bzero((char *) &serveraddr, sizeof(serveraddr)); 
  serveraddr.sin_family = AF_INET;  
  serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);  
  serveraddr.sin_port = htons((unsigned short)port_udp);  
  
  if (bind(listenfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0) {
    perror("Bind failed.!");
    return -1; 
  }
  return listenfd;
}
