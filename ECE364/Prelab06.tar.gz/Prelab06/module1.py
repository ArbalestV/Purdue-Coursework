def Add(num1, num2):
    return num1+num2

def Multiply(num1, num2):
    return num1*num2

c = 9
print "Random line right here"

def longer_function(a=1,b=3, c):
    print "This is a function"
    for i in c:
        d = a + b
        print d
    return a

for a in range(0, 10):
    print "Hello world"


