# Import PySide classes
from PySide.QtCore import *
from PySide.QtGui import *

from <Module Name> import *

class <Consumer Class Name>(QMainWindow, <UI Class Name>):

    def __init__(self, parent=None):
        super(<Consumer Class Name>, self).__init__(parent)
        self.setupUi(self)

currentApp = QApplication(sys.argv)
currentForm = <Consumer Class Name>()

currentForm.show()
currentApp.exec_()
